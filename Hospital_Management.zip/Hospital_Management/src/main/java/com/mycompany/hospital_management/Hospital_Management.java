/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.hospital_management;

import java.util.ArrayList;


public class Hospital_Management {
    public static ArrayList<String> Username = new ArrayList<>();
    public static ArrayList<String> Password = new ArrayList<>();   
    public static ArrayList<String> Uname = new ArrayList<>();
    public static ArrayList<String> ReEnter2 = new ArrayList<>();
    public static ArrayList<Patient> patients = new ArrayList<>();
    public static ArrayList<Diagnosis> diagnosis = new ArrayList<>();
    public static ArrayList<User> user = new ArrayList<>();
    public static ArrayList<Appointment> point = new ArrayList<>();
    public static ArrayList<JButton> buttonlist = new ArrayList<>();
    
//  RegisterFrame
    public static class User { 
    private String User;
    private String AccName;
    private String UserName;
    private String PassName;
    private String ReEnterName;
    
    public User(String User, String AccName, String UserName, String PassName, String ReEnterName) {
        this.User = User;
        this.AccName = AccName;
        this.UserName = UserName;
        this.PassName = PassName;
        this.ReEnterName = ReEnterName;
    }
//  Getters
    public String getUser() {return User; }
    public String getAccName() { return AccName; }
    public String getUserName() { return UserName; }
    public String getPassName() { return PassName; }
    public String getReEnterName() { return ReEnterName; }
    }
//  PatientFrame
    public static class Patient {
    private String id;
    private String firstName;
    private String lastName;
    private String age;
    private String gender;
    private String disease;
    private String dateOfBirth;
    private String status;
    private String number;
    private String address;
    private String bloodType;
    
    public Patient(String id, String firstName, String lastName, String age, String gender, String disease,
                   String dateOfBirth, String status, String number, String address, String bloodType) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.gender = gender;
        this.disease = disease;
        this.dateOfBirth = dateOfBirth;
        this.status = status;
        this.number = number;
        this.address = address;
        this.bloodType = bloodType;
    } 
    public String getId() {return id; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getAge() { return age; }
    public String getGender() { return gender; }
    public String getDisease() { return disease; }
    public String getDateOfBirth() { return dateOfBirth; }
    public String getStatus() { return status; }
    public String getNumber() { return number; }
    public String getAddress() { return address; }
    public String getBloodType() { return bloodType; }
  }
    public static class Diagnosis {
      private String Name;
      private String patient2;
      private String doctor;
      private String diagnosis2;
      private String medicine;
      
      public Diagnosis(String Name, String patient2, String doctor, String diagnosis2, String medicine) {
          this.Name = Name;
          this.patient2 = patient2;
          this.doctor = doctor;
          this.diagnosis2 = diagnosis2;
          this.medicine = medicine;
      }
      public String getName() { return Name; }
      public String getpatient2() { return patient2; }
      public String getdoctor() { return doctor; }
      public String getdiagnosis2() {return diagnosis2; }
      public String getmedicine() { return medicine; }
    }
    public static class Appointment {
      private String namepoint;
      private String datepoint;
      private String timepoint;
      private String DocBox;
      
      public Appointment (String namepoint, String datepoint, String timepoint, String DocBox) {
          this.namepoint = namepoint;
          this.datepoint = datepoint;
          this.timepoint = timepoint;
          this.DocBox = DocBox;
      }
      public String getnamepoint() { return namepoint; }
      public String getdatepoint() { return datepoint; }
      public String gettimepoint() { return timepoint; }
      public String getDocBox() { return DocBox; }
    }
    public static class JButton {
        private String selectedRoom;
        
    }   
}
    

