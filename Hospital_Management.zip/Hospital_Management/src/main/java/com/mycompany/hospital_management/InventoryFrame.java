/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.hospital_management;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author MK
 */
public class InventoryFrame extends javax.swing.JFrame {
//    private jTextArea RecipeArea;
    /**
     * Creates new form InventoryFrame
     */
    public InventoryFrame() {
        initComponents();
        setLocationRelativeTo(null);
        
    } 
    @SuppressWarnings("unchecked")

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        jButton14 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jButton15 = new javax.swing.JButton();
        jButton16 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        jButton19 = new javax.swing.JButton();
        jButton20 = new javax.swing.JButton();
        jButton21 = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        btnPhp = new javax.swing.JButton();
        btn7 = new javax.swing.JButton();
        btn8 = new javax.swing.JButton();
        btn9 = new javax.swing.JButton();
        btn6 = new javax.swing.JButton();
        btn5 = new javax.swing.JButton();
        btn4 = new javax.swing.JButton();
        btn3 = new javax.swing.JButton();
        btn2 = new javax.swing.JButton();
        btn1 = new javax.swing.JButton();
        btn0 = new javax.swing.JButton();
        btndot = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        DisplaySubTotal = new javax.swing.JTextField();
        DisplayTax = new javax.swing.JTextField();
        DisplayTotal = new javax.swing.JTextField();
        jPanel8 = new javax.swing.JPanel();
        PayMethodBox = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        CashDisplay = new javax.swing.JTextField();
        ChangeDisplay = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jButton34 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton35 = new javax.swing.JButton();
        RecipeButton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setPreferredSize(new java.awt.Dimension(1140, 570));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Georgia", 1, 50)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("SOUTH CARE HEALTH CENTER");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(125, 0, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\MK\\Downloads\\colorborder.jpg")); // NOI18N
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1120, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 1120, 60));

        jPanel3.setBackground(new java.awt.Color(0, 0, 0));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 25)); // NOI18N
        jButton1.setText("HOME");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 170, 40));

        jButton2.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton2.setText("DASHBOARD");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 170, 40));

        jButton3.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 17)); // NOI18N
        jButton3.setText("APPOINTMENT");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 170, 40));

        jButton4.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton4.setText("DIAGNOSIS");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 170, 40));

        jButton5.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton5.setText("DOCTOR");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 170, 40));

        jButton6.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton6.setText("PATIENT");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 170, 40));

        jButton7.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton7.setText("FACILITIES");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 170, 40));

        jButton8.setBackground(new java.awt.Color(0, 255, 255));
        jButton8.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton8.setForeground(new java.awt.Color(255, 0, 0));
        jButton8.setText("PHARMACY");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 280, 170, 40));

        jButton9.setBackground(new java.awt.Color(0, 255, 255));
        jButton9.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton9.setForeground(new java.awt.Color(255, 0, 0));
        jButton9.setText("PAYMENT");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 320, 170, 40));

        jButton10.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton10.setText("ACCOUNT");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 360, 170, 40));

        jButton11.setBackground(new java.awt.Color(255, 255, 0));
        jButton11.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton11.setText("BACK");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 400, 170, 40));

        jButton12.setBackground(new java.awt.Color(255, 0, 0));
        jButton12.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton12.setText("LOGOUT");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 440, 170, 40));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 170, 480));

        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 50)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("PHARMACY/PAYMENT");
        jPanel4.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 0, -1, -1));

        jTable1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item", "Qty", "Amount"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel4.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 380, 230));

        jPanel5.setBackground(new java.awt.Color(0, 0, 0));
        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton14.setIcon(new javax.swing.ImageIcon("C:\\Users\\MK\\Downloads\\medic8.jpg")); // NOI18N
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton14, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 120, 120, 110));

        jLabel10.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 25)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 204, 0));
        jLabel10.setText("98.89");
        jPanel5.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, -1, -1));

        jButton15.setIcon(new javax.swing.ImageIcon("C:\\Users\\MK\\Downloads\\medic1.png")); // NOI18N
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton15, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 120, 110));

        jButton16.setIcon(new javax.swing.ImageIcon("C:\\Users\\MK\\Downloads\\medic2.jpg")); // NOI18N
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton16, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 0, 120, 110));

        jButton17.setIcon(new javax.swing.ImageIcon("C:\\Users\\MK\\Downloads\\medic3.jpg")); // NOI18N
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton17, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 0, 120, 110));

        jButton18.setIcon(new javax.swing.ImageIcon("C:\\Users\\MK\\Downloads\\medic4.jpg")); // NOI18N
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton18, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 0, 120, 110));

        jButton19.setIcon(new javax.swing.ImageIcon("C:\\Users\\MK\\Downloads\\medic5.jpg")); // NOI18N
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton19, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 120, 110));

        jButton20.setIcon(new javax.swing.ImageIcon("C:\\Users\\MK\\Downloads\\medic6.jpg")); // NOI18N
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton20, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 120, 120, 110));

        jButton21.setIcon(new javax.swing.ImageIcon("C:\\Users\\MK\\Downloads\\medic7.jpg")); // NOI18N
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton21, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 120, 120, 110));

        jPanel4.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 60, 530, 230));

        jPanel6.setBackground(new java.awt.Color(0, 0, 0));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnPhp.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnPhp.setText("C");
        btnPhp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPhpActionPerformed(evt);
            }
        });
        jPanel6.add(btnPhp, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 110, 40, 40));

        btn7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btn7.setText("7");
        btn7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn7ActionPerformed(evt);
            }
        });
        jPanel6.add(btn7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 40, 40));

        btn8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btn8.setText("8");
        btn8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn8ActionPerformed(evt);
            }
        });
        jPanel6.add(btn8, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 10, 40, 40));

        btn9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btn9.setText("9");
        btn9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn9ActionPerformed(evt);
            }
        });
        jPanel6.add(btn9, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 10, 40, 40));

        btn6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btn6.setText("6");
        btn6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn6ActionPerformed(evt);
            }
        });
        jPanel6.add(btn6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 40, 40));

        btn5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btn5.setText("5");
        btn5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn5ActionPerformed(evt);
            }
        });
        jPanel6.add(btn5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 60, 40, 40));

        btn4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btn4.setText("4");
        btn4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn4ActionPerformed(evt);
            }
        });
        jPanel6.add(btn4, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 60, 40, 40));

        btn3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btn3.setText("3");
        btn3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn3ActionPerformed(evt);
            }
        });
        jPanel6.add(btn3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 40, 40));

        btn2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btn2.setText("2");
        btn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn2ActionPerformed(evt);
            }
        });
        jPanel6.add(btn2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 110, 40, 40));

        btn1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btn1.setText("1");
        btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn1ActionPerformed(evt);
            }
        });
        jPanel6.add(btn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 110, 40, 40));

        btn0.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btn0.setText("0");
        btn0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn0ActionPerformed(evt);
            }
        });
        jPanel6.add(btn0, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 10, 40, 40));

        btndot.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btndot.setText(".");
        btndot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndotActionPerformed(evt);
            }
        });
        jPanel6.add(btndot, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 60, 40, 40));

        jPanel4.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, 210, 160));

        jPanel7.setBackground(new java.awt.Color(0, 0, 0));
        jPanel7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 15)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("SUB TOTAL :");
        jPanel7.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, -1, 30));

        jLabel8.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("TAX :");
        jPanel7.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(59, 60, -1, -1));

        jLabel9.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText(" TOTAL :");
        jPanel7.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 100, -1, -1));

        DisplaySubTotal.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jPanel7.add(DisplaySubTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 20, 90, -1));

        DisplayTax.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jPanel7.add(DisplayTax, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 60, 90, -1));

        DisplayTotal.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jPanel7.add(DisplayTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 100, 90, -1));

        jPanel4.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 300, 230, 160));

        jPanel8.setBackground(new java.awt.Color(0, 0, 0));
        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        PayMethodBox.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        PayMethodBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "CASH", "CREDIT CARD", "DEBIT CARD" }));
        jPanel8.add(PayMethodBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, 170, 20));

        jLabel5.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("CASH :");
        jPanel8.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 70, -1, -1));

        jLabel6.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("CHANGE :");
        jPanel8.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(8, 110, -1, -1));

        CashDisplay.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jPanel8.add(CashDisplay, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 70, 100, -1));

        ChangeDisplay.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jPanel8.add(ChangeDisplay, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 110, 100, -1));

        jLabel11.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("MODE OF PAYMENT");
        jPanel8.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jPanel4.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 300, 230, 160));

        jPanel9.setBackground(new java.awt.Color(0, 0, 0));
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton34.setBackground(new java.awt.Color(0, 255, 0));
        jButton34.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton34.setText("CLEAR");
        jButton34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton34ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton34, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 200, 40));

        jButton13.setBackground(new java.awt.Color(0, 204, 255));
        jButton13.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton13.setText("PAY");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 200, 40));

        jButton35.setBackground(new java.awt.Color(255, 0, 0));
        jButton35.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton35.setText("REMOVE");
        jButton35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton35ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton35, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 200, 40));

        jPanel4.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 300, 220, 160));

        RecipeButton.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        RecipeButton.setText("RECIPE");
        RecipeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RecipeButtonActionPerformed(evt);
            }
        });
        jPanel4.add(RecipeButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 20, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\MK\\Downloads\\colorborder2.jpg")); // NOI18N
        jPanel4.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 80, 940, 480));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1140, 570));

        pack();
    }// </editor-fold>//GEN-END:initComponents
//======================Funtion=======================
    public void ItemCost() {
        double sum = 0;
        
        for(int i = 0; i <jTable1.getRowCount(); i++) {
            sum = sum + Double.parseDouble(jTable1.getValueAt(i, 2).toString());
        }
        DisplaySubTotal.setText(Double.toString(sum));
        double cTotal1 = Double.parseDouble(DisplaySubTotal.getText());
        
        double cTax = (cTotal1 * 3.9)/100;
        String iTaxTotal = String.format("$ % .2f",cTax);
        DisplayTax.setText(iTaxTotal);
        
        String iSubTotal = String.format("$ % .2f",cTotal1);
        DisplaySubTotal.setText(iSubTotal);
        
        String iTotal = String.format("$ % .2f",cTotal1 + cTax);
        DisplayTotal.setText(iTotal);
    }
//==========================Function Change=======================
    public void Change() {
        double sum = 0;
        double tax = 3.9;
        double cash = Double.parseDouble(CashDisplay.getText());
        
        for (int i = 0; i < jTable1.getRowCount(); i++) {
            sum = sum + Double.parseDouble(jTable1.getValueAt(i, 2).toString());
        }
        double cTax = (sum*3.9)/100;
        double cChange = (cash - (sum + cTax));
        
        String ChangeGiven = String .format("$ % .2f",cChange);
        ChangeDisplay.setText(ChangeGiven);
    }
    private void showData() {
    StringBuilder data = new StringBuilder();
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    for (int i = 0; i < model.getRowCount(); i++) {
        String item = model.getValueAt(i, 0).toString();
        String qty = model.getValueAt(i, 1).toString();
        String amount = model.getValueAt(i, 2).toString();
        data.append("Item: ").append(item)
            .append(", Qty: ").append(qty)
            .append(", Amount: ").append(amount)
            .append("\n");
    }   
}
    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        String AdminPass = "shiro"; // Predefined password
        String inputPassword = JOptionPane.showInputDialog(null, "Enter Password:", "Password Required", JOptionPane.PLAIN_MESSAGE);

        if (inputPassword != null && inputPassword.equals(AdminPass)) {
            DiagnosisFrame diagnosis = new DiagnosisFrame();
            diagnosis.setVisible(true);
            this.setVisible(false);
        } else {
            JOptionPane.showMessageDialog(null, "Access Denied!");
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        String AdminPass = "shiro"; // Predefined password
        String inputPassword = JOptionPane.showInputDialog(null, "Enter Password:", "Password Required", JOptionPane.PLAIN_MESSAGE);

        if (inputPassword != null && inputPassword.equals(AdminPass)) {
             AccountFrame account = new AccountFrame();
            account.setVisible(true);
            this.setVisible(false);
        } else {
            JOptionPane.showMessageDialog(null, "Access Denied!");
        }
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        int exit = JOptionPane.showConfirmDialog(null,"Are you sure you want to Log out?","Confirmation",JOptionPane.YES_NO_OPTION,
                JOptionPane.INFORMATION_MESSAGE);
        if (exit == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
        else {
            JOptionPane.showMessageDialog(null, "Cancellation Confirm.");
        }
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        if (PayMethodBox.getSelectedItem().equals("CASH")){
            Change();
        }
        else {
            ChangeDisplay.setText("");
            CashDisplay.setText("");
        }
    }//GEN-LAST:event_jButton13ActionPerformed

    private void btn7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn7ActionPerformed
        String EnterNumber = CashDisplay.getText();
        
        if (EnterNumber == " ") {
            CashDisplay.setText(btn7.getText());
        }
        else {
            EnterNumber = CashDisplay.getText() + btn7.getText();
            CashDisplay.setText(EnterNumber);
        }
    }//GEN-LAST:event_btn7ActionPerformed

    private void btn8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn8ActionPerformed
         String EnterNumber = CashDisplay.getText();
        
        if (EnterNumber == " ") {
            CashDisplay.setText(btn8.getText());
        }
        else {
            EnterNumber = CashDisplay.getText() + btn8.getText();
            CashDisplay.setText(EnterNumber);
        }
    }//GEN-LAST:event_btn8ActionPerformed

    private void btn9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn9ActionPerformed
         String EnterNumber = CashDisplay.getText();
        
        if (EnterNumber == " ") {
            CashDisplay.setText(btn9.getText());
        }
        else {
            EnterNumber = CashDisplay.getText() + btn9.getText();
            CashDisplay.setText(EnterNumber);
        }
    }//GEN-LAST:event_btn9ActionPerformed

    private void btn6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn6ActionPerformed
         String EnterNumber = CashDisplay.getText();
        
        if (EnterNumber == " ") {
            CashDisplay.setText(btn6.getText());
        }
        else {
            EnterNumber = CashDisplay.getText() + btn6.getText();
            CashDisplay.setText(EnterNumber);
        }
    }//GEN-LAST:event_btn6ActionPerformed

    private void btn5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn5ActionPerformed
         String EnterNumber = CashDisplay.getText();
        
        if (EnterNumber == " ") {
            CashDisplay.setText(btn5.getText());
        }
        else {
            EnterNumber = CashDisplay.getText() + btn5.getText();
            CashDisplay.setText(EnterNumber);
        }
    }//GEN-LAST:event_btn5ActionPerformed

    private void btn4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn4ActionPerformed
         String EnterNumber = CashDisplay.getText();
        
        if (EnterNumber == " ") {
            CashDisplay.setText(btn4.getText());
        }
        else {
            EnterNumber = CashDisplay.getText() + btn4.getText();
            CashDisplay.setText(EnterNumber);
        }
    }//GEN-LAST:event_btn4ActionPerformed

    private void btn3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn3ActionPerformed
         String EnterNumber = CashDisplay.getText();
        
        if (EnterNumber == " ") {
            CashDisplay.setText(btn3.getText());
        }
        else {
            EnterNumber = CashDisplay.getText() + btn3.getText();
            CashDisplay.setText(EnterNumber);
        }
    }//GEN-LAST:event_btn3ActionPerformed

    private void btn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn2ActionPerformed
         String EnterNumber = CashDisplay.getText();
        
        if (EnterNumber == " ") {
            CashDisplay.setText(btn2.getText());
        }
        else {
            EnterNumber = CashDisplay.getText() + btn2.getText();
            CashDisplay.setText(EnterNumber);
        }
    }//GEN-LAST:event_btn2ActionPerformed

    private void btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn1ActionPerformed
         String EnterNumber = CashDisplay.getText();
        
        if (EnterNumber == " ") {
            CashDisplay.setText(btn1.getText());
        }
        else {
            EnterNumber = CashDisplay.getText() + btn1.getText();
            CashDisplay.setText(EnterNumber);
        }
    }//GEN-LAST:event_btn1ActionPerformed

    private void btn0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn0ActionPerformed
         String EnterNumber = CashDisplay.getText();
        
        if (EnterNumber == " ") {
            CashDisplay.setText(btn0.getText());
        }
        else {
            EnterNumber = CashDisplay.getText() + btn0.getText();
            CashDisplay.setText(EnterNumber);
        }
    }//GEN-LAST:event_btn0ActionPerformed

    private void btndotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndotActionPerformed
        if(!CashDisplay.getText().contains(".")) {
            CashDisplay.setText(CashDisplay.getText() + btndot.getText());
        }
    }//GEN-LAST:event_btndotActionPerformed

    private void btnPhpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPhpActionPerformed
        CashDisplay.setText("");
        ChangeDisplay.setText("");
    }//GEN-LAST:event_btnPhpActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        double PriceOfItem = 98.89;
        
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        model.addRow(new Object[]{"Paracetamol", "1",PriceOfItem});
        ItemCost();
    }//GEN-LAST:event_jButton15ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        
    }//GEN-LAST:event_jTable1MouseClicked

    private void jButton34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton34ActionPerformed
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        model.setRowCount(0);
        CashDisplay.setText("");
        ChangeDisplay.setText("");
        DisplaySubTotal.setText("");
        DisplayTax.setText("");
        DisplayTotal.setText("");
    }//GEN-LAST:event_jButton34ActionPerformed

    private void jButton35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton35ActionPerformed
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        
        int RemoveItem = jTable1.getSelectedRow();
        if(RemoveItem >= 0) {
                model.removeRow(RemoveItem);
        }
        ItemCost();
        if (PayMethodBox.getSelectedItem().equals("CASH")) {
            Change();
        }
        else {
            CashDisplay.setText("");
            ChangeDisplay.setText("");
        }
    }//GEN-LAST:event_jButton35ActionPerformed

    private void RecipeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RecipeButtonActionPerformed
        StringBuilder data = new StringBuilder();
        javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) jTable1.getModel();
        for (int i = 0; i < model.getRowCount(); i++) {
        Object item = model.getValueAt(i, 0);
        Object qty = model.getValueAt(i, 1);
        Object amount = model.getValueAt(i, 2);
        data.append("Item: ").append(item)
            .append(", Qty: ").append(qty)
            .append(", Amount: ").append(amount)
            .append("\n");
    }
        PaymentFrame displayFrame = new PaymentFrame();
        displayFrame.setText(data.toString());
        displayFrame.setVisible(true);
//          PaymentFrame pay = new PaymentFrame();
//          pay.setVisible(true);
//          this.setVisible(false);

    }//GEN-LAST:event_RecipeButtonActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        DashBoardAdmin admin = new DashBoardAdmin();
        admin.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        FacilitiesFrame facilities = new FacilitiesFrame();
        facilities.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        HomeFrame home = new HomeFrame();
        home.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        DashBoardAdmin admin = new DashBoardAdmin();
        admin.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        AppointmentFrame appointment = new AppointmentFrame();
        appointment.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        PatientFrame patient = new PatientFrame();
        patient.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        DoctorFrame doctor = new DoctorFrame();
        doctor.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        InventoryFrame pharmacy = new InventoryFrame();
        pharmacy.setVisible(true);
        this.setVisible(false); 
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
       InventoryFrame pharmacy = new InventoryFrame();
       pharmacy.setVisible(true);
       this.setVisible(false); 
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
       double PriceOfItem = 100.67;
        
       DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
       model.addRow(new Object[]{"Ibuprofen", "1",PriceOfItem});
       ItemCost();
    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
       double PriceOfItem = 57.45;
        
       DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
       model.addRow(new Object[]{"Cough Syrup", "1",PriceOfItem});
       ItemCost();
    }//GEN-LAST:event_jButton17ActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
       double PriceOfItem = 120.38;
        
       DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
       model.addRow(new Object[]{"Probiotics", "1",PriceOfItem});
       ItemCost();
    }//GEN-LAST:event_jButton18ActionPerformed

    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed
       double PriceOfItem = 99.99;
        
       DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
       model.addRow(new Object[]{"Strepsils", "1",PriceOfItem});
       ItemCost();
    }//GEN-LAST:event_jButton19ActionPerformed

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
       double PriceOfItem = 65.19;
        
       DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
       model.addRow(new Object[]{"Pain Relievers", "1",PriceOfItem});
       ItemCost();
    }//GEN-LAST:event_jButton20ActionPerformed

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
       double PriceOfItem = 79.82;
        
       DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
       model.addRow(new Object[]{"Losartan", "1",PriceOfItem});
       ItemCost();
    }//GEN-LAST:event_jButton21ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
       double PriceOfItem = 140.63;
        
       DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
       model.addRow(new Object[]{"Treatment Cream", "1",PriceOfItem});
       ItemCost();
    }//GEN-LAST:event_jButton14ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InventoryFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InventoryFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InventoryFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InventoryFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InventoryFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField CashDisplay;
    private javax.swing.JTextField ChangeDisplay;
    private javax.swing.JTextField DisplaySubTotal;
    private javax.swing.JTextField DisplayTax;
    private javax.swing.JTextField DisplayTotal;
    private javax.swing.JComboBox<String> PayMethodBox;
    private javax.swing.JButton RecipeButton;
    private javax.swing.JButton btn0;
    private javax.swing.JButton btn1;
    private javax.swing.JButton btn2;
    private javax.swing.JButton btn3;
    private javax.swing.JButton btn4;
    private javax.swing.JButton btn5;
    private javax.swing.JButton btn6;
    private javax.swing.JButton btn7;
    private javax.swing.JButton btn8;
    private javax.swing.JButton btn9;
    private javax.swing.JButton btnPhp;
    private javax.swing.JButton btndot;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton34;
    private javax.swing.JButton jButton35;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables

    
}
