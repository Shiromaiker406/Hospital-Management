/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.hospital_management;

import com.mycompany.hospital_management.Hospital_Management.User;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author MK
 */
public class AccountFrame extends javax.swing.JFrame {

    /**
     * Creates new form AccountFrame
     */
    public AccountFrame() {
        initComponents();
        setLocationRelativeTo(null);
        loadAccountDataToTable();  
    }
    
    public void loadAccountDataToTable() {
    DefaultTableModel model = (DefaultTableModel) AccountTable.getModel();
    model.setRowCount(0); // Clear old data

    for (Hospital_Management.User a : Hospital_Management.user) {
        model.addRow(new Object[]{
            a.getUser(),
            a.getAccName(),
            a.getUserName(),
            a.getPassName(),
            a.getReEnterName()           
        });
    }
}

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        NameText = new javax.swing.JTextField();
        UserNameText = new javax.swing.JTextField();
        PassText = new javax.swing.JTextField();
        ReEnterText = new javax.swing.JTextField();
        SaveAccount = new javax.swing.JButton();
        ClearAccount = new javax.swing.JButton();
        DeleteAccount = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        UserBox = new javax.swing.JComboBox<>();
        UpdateAcccount = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        AccountTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setFont(new java.awt.Font("Georgia", 1, 50)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("SOUTH CARE HEALTH CENTER");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(125, 0, -1, -1));

        jLabel8.setIcon(new javax.swing.ImageIcon("C:\\Users\\MK\\Downloads\\colorborder.jpg")); // NOI18N
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 1120, 60));

        jPanel3.setBackground(new java.awt.Color(0, 0, 0));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton9.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton9.setText("DOCTOR");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 170, 40));

        jButton10.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton10.setText("DIAGNOSIS");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 170, 40));

        jButton11.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton11.setText("PATIENT");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 170, 40));

        jButton12.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 17)); // NOI18N
        jButton12.setText("APPOINTMENT");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 170, 40));

        jButton13.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton13.setText("FACILITIES");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 170, 40));

        jButton14.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton14.setText("PAYMENT");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton14, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 320, 170, 40));

        jButton15.setBackground(new java.awt.Color(0, 255, 255));
        jButton15.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton15.setForeground(new java.awt.Color(255, 0, 0));
        jButton15.setText("ACCOUNT");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton15, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 360, 170, 40));

        jButton1.setBackground(new java.awt.Color(255, 0, 0));
        jButton1.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton1.setText("LOGOUT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 440, 170, 40));

        jButton5.setBackground(new java.awt.Color(255, 255, 0));
        jButton5.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton5.setText("BACK");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 400, 170, 40));

        jButton6.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton6.setText("DASHBOARD");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 170, 40));

        jButton2.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 25)); // NOI18N
        jButton2.setText("HOME");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 170, 40));

        jButton3.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton3.setText("PHARMACY");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 280, 170, 40));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 170, 480));

        jPanel4.setBackground(new java.awt.Color(51, 204, 255));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Berlin Sans FB", 1, 35)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("ACCOUNT");
        jPanel4.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 10, 180, -1));

        jLabel2.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel2.setText("NAME :");
        jPanel4.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 130, -1, -1));

        jLabel3.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel3.setText("USERNAME :");
        jPanel4.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 180, -1, -1));

        jLabel4.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel4.setText("PASSWORD :");
        jPanel4.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 230, -1, -1));

        jLabel5.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel5.setText("RE ENTER : ");
        jPanel4.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 280, -1, -1));

        NameText.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jPanel4.add(NameText, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 130, 200, -1));

        UserNameText.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jPanel4.add(UserNameText, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 180, 200, -1));

        PassText.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jPanel4.add(PassText, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 230, 200, -1));

        ReEnterText.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jPanel4.add(ReEnterText, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 280, 200, -1));

        SaveAccount.setBackground(new java.awt.Color(0, 0, 255));
        SaveAccount.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 15)); // NOI18N
        SaveAccount.setText("SAVE");
        SaveAccount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveAccountActionPerformed(evt);
            }
        });
        jPanel4.add(SaveAccount, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 330, 100, 50));

        ClearAccount.setBackground(new java.awt.Color(0, 204, 0));
        ClearAccount.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 15)); // NOI18N
        ClearAccount.setText("CLEAR");
        ClearAccount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearAccountActionPerformed(evt);
            }
        });
        jPanel4.add(ClearAccount, new org.netbeans.lib.awtextra.AbsoluteConstraints(235, 330, 100, 50));

        DeleteAccount.setBackground(new java.awt.Color(255, 0, 0));
        DeleteAccount.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 15)); // NOI18N
        DeleteAccount.setText("DELETE");
        DeleteAccount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteAccountActionPerformed(evt);
            }
        });
        jPanel4.add(DeleteAccount, new org.netbeans.lib.awtextra.AbsoluteConstraints(345, 330, 100, 50));

        jLabel7.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel7.setText("USER :");
        jPanel4.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 80, -1, -1));

        UserBox.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        UserBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "DOCTOR", "PATIENT", "EMPLOYEE", " " }));
        UserBox.setSelectedIndex(-1);
        jPanel4.add(UserBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 80, -1, -1));

        UpdateAcccount.setBackground(new java.awt.Color(0, 255, 255));
        UpdateAcccount.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 15)); // NOI18N
        UpdateAcccount.setText("UPDATE");
        UpdateAcccount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateAcccountActionPerformed(evt);
            }
        });
        jPanel4.add(UpdateAcccount, new org.netbeans.lib.awtextra.AbsoluteConstraints(125, 330, 100, 50));

        jLabel9.setIcon(new javax.swing.ImageIcon("C:\\Users\\MK\\Downloads\\colorborder2.jpg")); // NOI18N
        jPanel4.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 460, -1));

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 80, 460, 480));

        AccountTable.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        AccountTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "User", "Name", "Username", "Password", "ReEnter"
            }
        ));
        AccountTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AccountTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(AccountTable);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 80, 470, 480));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1140, 570));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        DashBoardAdmin admin = new DashBoardAdmin();
        admin.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        DoctorFrame doctor = new DoctorFrame();
        doctor.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        String AdminPass = "shiro"; // Predefined password
        String inputPassword = JOptionPane.showInputDialog(null, "Enter Password:", "Password Required", JOptionPane.PLAIN_MESSAGE);

        if (inputPassword != null && inputPassword.equals(AdminPass)) {
            DiagnosisFrame diagnosis = new DiagnosisFrame();
            diagnosis.setVisible(true);
            this.setVisible(false);
        } else {
            JOptionPane.showMessageDialog(null, "Access Denied!");
        }
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        PatientFrame patient = new PatientFrame();
        patient.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        AppointmentFrame appointment = new AppointmentFrame();
        appointment.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        FacilitiesFrame facilities = new FacilitiesFrame();
        facilities.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
       InventoryFrame pharmacy = new InventoryFrame();
       pharmacy.setVisible(true);
       this.setVisible(false); 
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        String AdminPass = "shiro"; // Predefined password
        String inputPassword = JOptionPane.showInputDialog(null, "Enter Password:", "Password Required", JOptionPane.PLAIN_MESSAGE);

        if (inputPassword != null && inputPassword.equals(AdminPass)) {
             AccountFrame account = new AccountFrame();
            account.setVisible(true);
            this.setVisible(false);
        } else {
            JOptionPane.showMessageDialog(null, "Access Denied!");
        }
    }//GEN-LAST:event_jButton15ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        DashBoardAdmin back = new DashBoardAdmin();
        back.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        int exit = JOptionPane.showConfirmDialog(null,"Are you sure you want to Log out?","Confirmation",JOptionPane.YES_NO_OPTION,
                JOptionPane.INFORMATION_MESSAGE);
        if (exit == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
        else {
            JOptionPane.showMessageDialog(null, "Cancellation Confirm.");
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void ClearAccountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearAccountActionPerformed
                if (NameText.getText().isEmpty() &&
                    UserNameText.getText().isEmpty() &&
                    PassText.getText().isEmpty() &&
                    ReEnterText.getText().isEmpty() &&
                    UserBox.getSelectedIndex() == -1 ) {
                
                    JOptionPane.showMessageDialog(null, "There are no text to clear",
                    "Input Error", JOptionPane.ERROR_MESSAGE);
                }
                else {
                    NameText.setText("");
                    UserNameText.setText("");
                    PassText.setText("");
                    ReEnterText.setText("");
                    UserBox.setSelectedIndex(-1);
                }
    }//GEN-LAST:event_ClearAccountActionPerformed

    private void SaveAccountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveAccountActionPerformed
        DefaultTableModel model = (DefaultTableModel) AccountTable.getModel();
        
        String AccName = NameText.getText().trim();
        String UserName = UserNameText.getText().trim();
        String PassName = PassText.getText().trim();
        String ReEnterName = ReEnterText.getText().trim();
        String User = (UserBox.getSelectedItem() != null) ? UserBox.getSelectedItem().toString().trim() : "";
        
        
        if (UserName.length()< 2){
            JOptionPane.showMessageDialog(this, "Username to short", "Minimum of 2 character required", JOptionPane.WARNING_MESSAGE);
            UserNameText.getText();
            return;
        }else if (UserName.length()>20) {
            JOptionPane.showMessageDialog(this, "Username to long", "Minimum Character are met", JOptionPane.WARNING_MESSAGE);
            UserNameText.getText();
            return;
        }
        
        if(AccName.isEmpty() || UserName.isEmpty() || PassName.isEmpty() || ReEnterName.isEmpty() || User.isEmpty()) {
            
            JOptionPane.showMessageDialog(this,
            "There are empty spots, please fill up again.",
            "Input Error",
            JOptionPane.ERROR_MESSAGE);
        }
        if (!PassName.equals(ReEnterName)) {
            JOptionPane.showMessageDialog(this, "Password do not Match!", "PASSWORD INCCORECT!", JOptionPane.WARNING_MESSAGE);
            PassText.getText();
            ReEnterText.getText();
            return;
        }
        if (PassName.length() < 10) {
            JOptionPane.showMessageDialog(this, "Password must contain only 10 characters", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        // Save to file              
            model.addRow(new Object[] {
                User, AccName, UserName, PassName, ReEnterName,                
            });
            Hospital_Management.User newUser = new Hospital_Management.User(User, AccName, UserName, PassName, ReEnterName);
            Hospital_Management.user.add(newUser);
        
        Hospital_Management.Username.add(UserName);
        Hospital_Management.Password.add(PassName);
        Hospital_Management.ReEnter2.add(ReEnterName);
        JOptionPane.showMessageDialog(null, "New Account Registered!");
    }//GEN-LAST:event_SaveAccountActionPerformed

    private void DeleteAccountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteAccountActionPerformed
        DefaultTableModel model = (DefaultTableModel)AccountTable.getModel();
        
        if(AccountTable.getSelectedRowCount()==1){
            model.removeRow(AccountTable.getSelectedRow());
        }else {
            if(AccountTable.getSelectedRowCount()==0){
                JOptionPane.showMessageDialog(this, "Please select a single row to Delete!", "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        } 
    }//GEN-LAST:event_DeleteAccountActionPerformed

    private void UpdateAcccountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateAcccountActionPerformed
        int user = AccountTable.getSelectedRow();
        String User = (String) UserBox.getSelectedItem();
        
        if(AccountTable.getSelectedRowCount()==1) {
            
            String AccName = NameText.getText();
            String UserName = UserNameText.getText();
            String PassName = PassText.getText();
            String ReEnterName = ReEnterText.getText();
            
        DefaultTableModel model = (DefaultTableModel)AccountTable.getModel();    
            model.setValueAt(User, user, 0);
            model.setValueAt(AccName, AccountTable.getSelectedRow(),1);
            model.setValueAt(UserName, AccountTable.getSelectedRow(),2);
            model.setValueAt(PassName, AccountTable.getSelectedRow(),3);
            model.setValueAt(ReEnterName, AccountTable.getSelectedRow(),4);
            
            Hospital_Management.User newUser = new Hospital_Management.User(User, AccName, UserName, PassName, ReEnterName);
            Hospital_Management.user.add(newUser);
            
            Hospital_Management.Username.add(UserName);
            Hospital_Management.Password.add(PassName);
            Hospital_Management.ReEnter2.add(ReEnterName);
               
            JOptionPane.showMessageDialog(this, "Update Successfully...");
        } else {
            JOptionPane.showMessageDialog(this, "Please Select a single row to Update!", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_UpdateAcccountActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        HomeFrame home = new HomeFrame();
        home.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void AccountTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AccountTableMouseClicked
        DefaultTableModel model = (DefaultTableModel)AccountTable.getModel();
    }//GEN-LAST:event_AccountTableMouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        InventoryFrame pharmacy = new InventoryFrame();
        pharmacy.setVisible(true);
        this.setVisible(false); 
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AccountFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AccountFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AccountFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AccountFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AccountFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable AccountTable;
    private javax.swing.JButton ClearAccount;
    private javax.swing.JButton DeleteAccount;
    private javax.swing.JTextField NameText;
    private javax.swing.JTextField PassText;
    private javax.swing.JTextField ReEnterText;
    private javax.swing.JButton SaveAccount;
    private javax.swing.JButton UpdateAcccount;
    private javax.swing.JComboBox<String> UserBox;
    private javax.swing.JTextField UserNameText;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
