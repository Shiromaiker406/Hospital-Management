/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.hospital_management;

import com.mycompany.hospital_management.Hospital_Management.Patient;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class PatientFrame extends javax.swing.JFrame {

    
    public PatientFrame() {
        initComponents();
        setLocationRelativeTo(null);
        loadPatientDataToTable();    
}
    public void loadPatientDataToTable() {
    DefaultTableModel model = (DefaultTableModel) PatientTable.getModel();
    model.setRowCount(0); // Clear old data

    for (Hospital_Management.Patient p : Hospital_Management.patients) {
        model.addRow(new Object[]{
            p.getId(),
            p.getFirstName(),
            p.getLastName(),
            p.getAge(),
            p.getGender(),
            p.getDisease(),
            p.getDateOfBirth(),
            p.getStatus(),
            p.getNumber(),
            p.getAddress(),
            p.getBloodType()
        });
    }
}   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        SavePatient = new javax.swing.JButton();
        ClearPatient = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        PatientBox = new javax.swing.JComboBox<>();
        FirstNameText = new javax.swing.JTextField();
        LastNameText = new javax.swing.JTextField();
        AgeText = new javax.swing.JTextField();
        BloodBox = new javax.swing.JComboBox<>();
        AddressText = new javax.swing.JTextField();
        NumberText = new javax.swing.JTextField();
        DiseaseBox = new javax.swing.JComboBox<>();
        UpdatePatient = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        DateBirthText = new javax.swing.JTextField();
        DeletePatient = new javax.swing.JButton();
        GenderBox = new javax.swing.JComboBox<>();
        StatusBox = new javax.swing.JComboBox<>();
        jButton5 = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jButton16 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        PatientTable = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(51, 204, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Berlin Sans FB", 1, 35)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("PATIENT FORM");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 10, -1, -1));

        SavePatient.setBackground(new java.awt.Color(51, 102, 255));
        SavePatient.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        SavePatient.setText("SAVE");
        SavePatient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SavePatientActionPerformed(evt);
            }
        });
        jPanel1.add(SavePatient, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 270, 130, 60));

        ClearPatient.setBackground(new java.awt.Color(0, 204, 0));
        ClearPatient.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        ClearPatient.setText("CLEAR");
        ClearPatient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearPatientActionPerformed(evt);
            }
        });
        jPanel1.add(ClearPatient, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 270, 130, 60));

        jLabel3.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel3.setText("FIRST NAME :");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(9, 98, -1, 30));

        jLabel4.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel4.setText("LAST NAME :");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 138, -1, 30));

        jLabel5.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel5.setText("AGE :");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(85, 180, -1, 30));

        jLabel6.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel6.setText("PHONE NUMBER :");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(353, 180, -1, 30));

        jLabel7.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel7.setText("PATIENT ADDRESS :");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 218, -1, 30));

        jLabel8.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel8.setText("PATIENT ID :");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 57, -1, 30));

        jLabel11.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel11.setText("MARTIAL STATUS :");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(341, 145, -1, -1));

        jLabel12.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel12.setText("GENDER :");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(44, 220, -1, -1));

        jLabel13.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel13.setText("BLOOD");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 100, -1, 30));

        jLabel14.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel14.setText("DISEASE :");
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(426, 63, -1, -1));

        PatientBox.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        PatientBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1234", "1345", "5356", "5156" }));
        PatientBox.setSelectedIndex(-1);
        PatientBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PatientBoxActionPerformed(evt);
            }
        });
        jPanel1.add(PatientBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 60, 170, -1));

        FirstNameText.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jPanel1.add(FirstNameText, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 100, 170, -1));

        LastNameText.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jPanel1.add(LastNameText, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 140, 170, -1));

        AgeText.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jPanel1.add(AgeText, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 180, 170, -1));

        BloodBox.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        BloodBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-" }));
        BloodBox.setSelectedIndex(-1);
        jPanel1.add(BloodBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 120, -1, -1));

        AddressText.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jPanel1.add(AddressText, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 220, 230, -1));

        NumberText.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jPanel1.add(NumberText, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 180, 230, -1));

        DiseaseBox.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        DiseaseBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "FLU", "HEADACHE", "SORE THROAT", "ACNE", "FOOD POISONING", "DIARRHEA", "MIGRAINE", "CHICKENPOX", " " }));
        DiseaseBox.setSelectedIndex(-1);
        jPanel1.add(DiseaseBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 60, 310, -1));

        UpdatePatient.setBackground(new java.awt.Color(0, 255, 255));
        UpdatePatient.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        UpdatePatient.setText("UPDATE");
        UpdatePatient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdatePatientActionPerformed(evt);
            }
        });
        jPanel1.add(UpdatePatient, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 270, 130, 60));

        jLabel15.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel15.setText("DATE OF BIRTH :");
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(361, 105, -1, 20));

        DateBirthText.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jPanel1.add(DateBirthText, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 100, 160, -1));

        DeletePatient.setBackground(new java.awt.Color(255, 0, 0));
        DeletePatient.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        DeletePatient.setText("DELETE");
        DeletePatient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeletePatientActionPerformed(evt);
            }
        });
        jPanel1.add(DeletePatient, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 270, 130, 60));

        GenderBox.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        GenderBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "MALE", "FEMALE", "OTHERS" }));
        GenderBox.setSelectedIndex(-1);
        jPanel1.add(GenderBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 220, 170, -1));

        StatusBox.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        StatusBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SINGLE", "MARRIAGE", "TAKEN" }));
        StatusBox.setSelectedIndex(-1);
        jPanel1.add(StatusBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 140, 160, -1));

        jButton5.setBackground(new java.awt.Color(255, 102, 255));
        jButton5.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 19)); // NOI18N
        jButton5.setText("PROCEED");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 270, 130, 60));

        jLabel18.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel18.setText("TYPE :");
        jPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 130, -1, -1));

        jLabel16.setIcon(new javax.swing.ImageIcon("C:\\Users\\MK\\Downloads\\colorborder2.jpg")); // NOI18N
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 350));

        jLabel17.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel17.setText("BLOOD");
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 100, -1, 30));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 80, 940, 350));

        jPanel2.setBackground(new java.awt.Color(0, 204, 255));
        jPanel2.setForeground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setFont(new java.awt.Font("Georgia", 1, 50)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("SOUTH CARE HEALTH CENTER");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(125, 0, -1, -1));

        jLabel9.setIcon(new javax.swing.ImageIcon("C:\\Users\\MK\\Downloads\\colorborder.jpg")); // NOI18N
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 1120, 60));

        jPanel4.setBackground(new java.awt.Color(0, 0, 0));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton10.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton10.setText("DOCTOR");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 170, 40));

        jButton11.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton11.setText("DIAGNOSIS");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 170, 40));

        jButton12.setBackground(new java.awt.Color(0, 255, 255));
        jButton12.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton12.setForeground(new java.awt.Color(255, 0, 0));
        jButton12.setText("PATIENT");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 170, 40));

        jButton13.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 17)); // NOI18N
        jButton13.setText("APPOINTMENT");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 170, 40));

        jButton14.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton14.setText("PAYMENT");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton14, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 320, 170, 40));

        jButton15.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton15.setText("ACCOUNT");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton15, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 360, 170, 40));

        jButton16.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton16.setText("FACILITIES");
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton16, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 170, 40));

        jButton3.setBackground(new java.awt.Color(255, 255, 0));
        jButton3.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton3.setText("BACK");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 400, 170, 40));

        jButton4.setBackground(new java.awt.Color(255, 0, 0));
        jButton4.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton4.setText("LOGOUT");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 440, 170, 40));

        jButton7.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton7.setText("DASHBOARD");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 170, 40));

        jButton1.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 25)); // NOI18N
        jButton1.setText("HOME");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 170, 40));

        jButton2.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton2.setText("PHARMACY");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 280, 170, 40));

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 170, 480));

        jPanel3.setBackground(new java.awt.Color(0, 0, 0));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        PatientTable.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        PatientTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "FirstName", "LastName", "Age", "Gender", "Disease", "DateBirth", "Status", "Number", "Address", "Blood"
            }
        ));
        PatientTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PatientTableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(PatientTable);

        jPanel3.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 440, 940, 120));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1140, 570));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\MK\\Downloads\\Hospital Management FINALS (4).jpg")); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1140, 570));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SavePatientActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SavePatientActionPerformed
    
    DefaultTableModel model = (DefaultTableModel) PatientTable.getModel();
    
    // Retrieve values from the text fields and combo boxes
    String patientId = (PatientBox.getSelectedItem() != null) ? PatientBox.getSelectedItem().toString().trim() : "";
    String firstName = FirstNameText.getText().trim();
    String lastName = LastNameText.getText().trim();
    String age = AgeText.getText().trim();
    String gender = (GenderBox.getSelectedItem() != null) ? GenderBox.getSelectedItem().toString().trim() : "";
    String disease = (DiseaseBox.getSelectedItem() != null) ? DiseaseBox.getSelectedItem().toString().trim() : "";
    String dateOfBirth = DateBirthText.getText().trim();
    String status = (StatusBox.getSelectedItem() != null) ? StatusBox.getSelectedItem().toString().trim() : "";
    String number = NumberText.getText().trim();
    String address = AddressText.getText().trim();
    String blood = (BloodBox.getSelectedItem() != null) ? BloodBox.getSelectedItem().toString().trim() : "";
    
    // Check text fields and combo boxes for empty values
    if (patientId.isEmpty() || firstName.isEmpty() || lastName.isEmpty() || age.isEmpty() || gender.isEmpty() ||
        disease.isEmpty() || dateOfBirth.isEmpty() || status.isEmpty() || number.isEmpty() || address.isEmpty() || 
        blood.isEmpty()) {

        JOptionPane.showMessageDialog(this,
            "There are empty spots, please fill up again.",
            "Input Error",
            JOptionPane.ERROR_MESSAGE);
        return;
    }
    // Add new row to JTable
    model.addRow(new Object[] {
        patientId, firstName, lastName, age, gender, disease, dateOfBirth, status, number, address, blood
    });
    // Add to static ArrayList
    Hospital_Management.Patient newPatient = new Hospital_Management.Patient(
        patientId, firstName, lastName, age, gender, disease, dateOfBirth, status, number, address, blood
    );
    Hospital_Management.patients.add(newPatient);

    // Optional success feedback
    JOptionPane.showMessageDialog(this, "Patient saved successfully.");
    
    }//GEN-LAST:event_SavePatientActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        int exit = JOptionPane.showConfirmDialog(null,"Are you sure you want to Log out?","Confirmation",JOptionPane.YES_NO_OPTION,
                JOptionPane.INFORMATION_MESSAGE);
        if (exit == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
        else {
            JOptionPane.showMessageDialog(null, "Cancellation Confirm.");
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void ClearPatientActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearPatientActionPerformed
        if (FirstNameText.getText().isEmpty() &&
            LastNameText.getText().isEmpty() &&
            AgeText.getText().isEmpty() &&
            AddressText.getText().isEmpty() &&
            NumberText.getText().isEmpty() &&
            DateBirthText.getText().isEmpty() &&
            PatientBox.getSelectedIndex() == -1 &&
            BloodBox.getSelectedIndex() == -1 &&
            DiseaseBox.getSelectedIndex() == -1 &&
            GenderBox.getSelectedIndex() == -1 &&
            StatusBox.getSelectedIndex() == -1) {
    
            JOptionPane.showMessageDialog(null, "There are no text to clear",
                "Input Error", JOptionPane.ERROR_MESSAGE);
    } else {
    // Clear all fields
            FirstNameText.setText("");
            LastNameText.setText("");
            AgeText.setText("");
            AddressText.setText("");
            NumberText.setText("");
            DateBirthText.setText("");
            PatientBox.setSelectedIndex(-1);
            BloodBox.setSelectedIndex(-1);
            DiseaseBox.setSelectedIndex(-1);
            GenderBox.setSelectedIndex(-1);
            StatusBox.setSelectedIndex(-1);
        } 
    }//GEN-LAST:event_ClearPatientActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        DashBoardAdmin back = new DashBoardAdmin();
        back.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        DashBoardAdmin admin = new DashBoardAdmin();
        admin.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        DoctorFrame doctor = new DoctorFrame();
        doctor.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        String AdminPass = "shiro"; // Predefined password
        String inputPassword = JOptionPane.showInputDialog(null, "Enter Password:", "Password Required", JOptionPane.PLAIN_MESSAGE);

        if (inputPassword != null && inputPassword.equals(AdminPass)) {
            DiagnosisFrame diagnosis = new DiagnosisFrame();
            diagnosis.setVisible(true);
            this.setVisible(false);
        } else {
            JOptionPane.showMessageDialog(null, "Access Denied!");
        }
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        PatientFrame patient = new PatientFrame();
//        patient.populateTable();
        patient.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        AppointmentFrame appointment = new AppointmentFrame();
        appointment.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
        FacilitiesFrame facilities = new FacilitiesFrame();
        facilities.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        InventoryFrame pharmacy = new InventoryFrame();
        pharmacy.setVisible(true);
        this.setVisible(false);     
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        String AdminPass = "shiro"; // Predefined password
        String inputPassword = JOptionPane.showInputDialog(null, "Enter Password:", "Password Required", JOptionPane.PLAIN_MESSAGE);

        if (inputPassword != null && inputPassword.equals(AdminPass)) {
             AccountFrame account = new AccountFrame();
            account.setVisible(true);
            this.setVisible(false);
        } else {
            JOptionPane.showMessageDialog(null, "Access Denied!");
        }
    }//GEN-LAST:event_jButton15ActionPerformed

    private void DeletePatientActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeletePatientActionPerformed
        DefaultTableModel model = (DefaultTableModel)PatientTable.getModel();
        
        if(PatientTable.getSelectedRowCount()==1){
            int selectedRow = PatientTable.getSelectedRow();
            model.removeRow(selectedRow);
            Hospital_Management.patients.remove(selectedRow);
        }else {
            if(PatientTable.getSelectedRowCount()==0){
                JOptionPane.showMessageDialog(this, "Please Select a single row to Delete", "Input Error!", JOptionPane.ERROR_MESSAGE);          
            }           
        }      
    }//GEN-LAST:event_DeletePatientActionPerformed

    private void UpdatePatientActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdatePatientActionPerformed
    int selectedRow = PatientTable.getSelectedRow();       
    if (selectedRow != -1) {
        // Update the selected row with new data
        String patientId = (String) PatientBox.getSelectedItem();
        String firstName = FirstNameText.getText();
        String lastName = LastNameText.getText();
        String age = AgeText.getText();
        String gender = (String) GenderBox.getSelectedItem();
        String disease = (String) DiseaseBox.getSelectedItem();
        String dateOfBirth = DateBirthText.getText();
        String status = (String) StatusBox.getSelectedItem();
        String number = NumberText.getText();
        String address = AddressText.getText();
        String blood = (String) BloodBox.getSelectedItem();
        
        // Update the table model
        DefaultTableModel model = (DefaultTableModel) PatientTable.getModel();
        model.setValueAt(patientId, selectedRow, 0);
        model.setValueAt(firstName, selectedRow, 1);
        model.setValueAt(lastName, selectedRow, 2);
        model.setValueAt(age, selectedRow, 3);
        model.setValueAt(gender, selectedRow, 4);
        model.setValueAt(disease, selectedRow, 5);
        model.setValueAt(dateOfBirth, selectedRow, 6);
        model.setValueAt(status, selectedRow, 7);
        model.setValueAt(number, selectedRow, 8);
        model.setValueAt(address, selectedRow, 9);
        model.setValueAt(blood, selectedRow, 10);
        
        // Update the patient list
        Hospital_Management.patients.set(selectedRow, new Patient(patientId, firstName, lastName, age, gender, disease,
                dateOfBirth, status, number, address, blood));
        
        JOptionPane.showMessageDialog(this, "Update Successfully...");
    } else {
        JOptionPane.showMessageDialog(this, "Please Select a single row to Update!", "Input Error", JOptionPane.ERROR_MESSAGE);
    }

        
    }//GEN-LAST:event_UpdatePatientActionPerformed

    private void PatientTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PatientTableMouseClicked
//        DefaultTableModel model = (DefaultTableModel)PatientTable.getModel();
//        
//        List<Object[]> dataList = new ArrayList<>();
//    
//    // Loop through the rows of the JTable
//        for (int i = 0; i < model.getRowCount(); i++) {
//        Object[] rowData = new Object[model.getColumnCount()];
//        for (int j = 0; j < model.getColumnCount(); j++) {
//            rowData[j] = model.getValueAt(i, j);
//        }
//        dataList.add(rowData); // Add the row data to the list
//    }
//        
//        String tblname = model.getValueAt(PatientTable.getSelectedRow(), 1).toString();
//        String tbllast = model.getValueAt(PatientTable.getSelectedRow(), 2).toString();
//        String tblage = model.getValueAt(PatientTable.getSelectedRow(), 3).toString();
//        String tbldatebirth = model.getValueAt(PatientTable.getSelectedRow(), 6).toString();        
//        String tblnumber = model.getValueAt(PatientTable.getSelectedRow(), 8).toString();
//        String tbladd = model.getValueAt(PatientTable.getSelectedRow(), 9).toString();
//       
//        FirstNameText.setText(tblname);
//        LastNameText.setText(tbllast);
//        AgeText.setText(tblage);
//        AddressText.setText(tbladd);
//        NumberText.setText(tblnumber);
//        DateBirthText.setText(tbldatebirth);
                                    
    }//GEN-LAST:event_PatientTableMouseClicked

    private void PatientBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PatientBoxActionPerformed

    }//GEN-LAST:event_PatientBoxActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       HomeFrame home = new HomeFrame();
       home.setVisible(true);
       this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        InventoryFrame pharmacy = new InventoryFrame();
        pharmacy.setVisible(true);
        this.setVisible(false); 
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
       DoctorFrame doctor = new DoctorFrame();
       doctor.setVisible(true);
       this.setVisible(false);
    }//GEN-LAST:event_jButton5ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PatientFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PatientFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PatientFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PatientFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PatientFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField AddressText;
    private javax.swing.JTextField AgeText;
    private javax.swing.JComboBox<String> BloodBox;
    private javax.swing.JButton ClearPatient;
    private javax.swing.JTextField DateBirthText;
    private javax.swing.JButton DeletePatient;
    private javax.swing.JComboBox<String> DiseaseBox;
    private javax.swing.JTextField FirstNameText;
    private javax.swing.JComboBox<String> GenderBox;
    private javax.swing.JTextField LastNameText;
    private javax.swing.JTextField NumberText;
    private javax.swing.JComboBox<String> PatientBox;
    private javax.swing.JTable PatientTable;
    private javax.swing.JButton SavePatient;
    private javax.swing.JComboBox<String> StatusBox;
    private javax.swing.JButton UpdatePatient;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables

//    } else 
//            {
//        // All fields are filled; add the new row
//            model.addRow(new Object[] {
//                patientId,
//                firstName,
//                lastName,
//                age,
//                gender,
//                disease,
//                dateOfBirth,
//                status,
//                number,
//                address,
//                blood,     
//            });
//            
//        Patient newPatient = new Patient(patientId, firstName, lastName, age, gender, disease, dateOfBirth, status, number, address, blood);
//        Hospital_Management.patients.add(newPatient);
//        }
    
}
