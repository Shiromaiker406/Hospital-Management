/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.hospital_management;

import com.mycompany.hospital_management.Hospital_Management.Diagnosis;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author MK
 */
public class DiagnosisFrame extends javax.swing.JFrame {

    /**
     * Creates new form DiagnosisFrame
     */
    public DiagnosisFrame() {
        initComponents();
        setLocationRelativeTo(null);
        loadPatientDataToTable();
        loadDiagnosisDataToTable();
    }
    public void loadPatientDataToTable() {
    DefaultTableModel model = (DefaultTableModel) PatientTable2.getModel();
    model.setRowCount(0); // Clear old data

    for (Hospital_Management.Patient p : Hospital_Management.patients) {
        model.addRow(new Object[]{
            p.getId(),
            p.getFirstName(),
            p.getLastName(),
            p.getAge(),
            p.getGender(),
            p.getDisease(),
            p.getDateOfBirth(),
            p.getStatus(),
            p.getNumber(),
            p.getAddress(),
            p.getBloodType()
        });
    }    
}
    public void loadDiagnosisDataToTable() {
    DefaultTableModel model = (DefaultTableModel) DiagnosisTable.getModel();
    model.setRowCount(0);
    
    for (Hospital_Management.Diagnosis d : Hospital_Management.diagnosis) {
        model.addRow(new Object [] {
            d.getName(),
            d.getpatient2(),
            d.getdoctor(),
            d.getdiagnosis2(),
            d.getmedicine()
        });
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jButton7 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jButton16 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        PatientBox2 = new javax.swing.JComboBox<>();
        NameText2 = new javax.swing.JTextField();
        DoctorBox = new javax.swing.JComboBox<>();
        DiagnosisBox = new javax.swing.JComboBox<>();
        MedicineBox = new javax.swing.JComboBox<>();
        SaveDiagnosis = new javax.swing.JButton();
        UpdateDiagnosis = new javax.swing.JButton();
        ClearDiagnosis = new javax.swing.JButton();
        DeleteDiagnosis = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        PatientTable2 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        DiagnosisTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Georgia", 1, 50)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("SOUTH CARE HEALTH CENTER ");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(125, 0, 860, -1));

        jLabel9.setIcon(new javax.swing.ImageIcon("C:\\Users\\MK\\Downloads\\colorborder.jpg")); // NOI18N
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 1120, 60));

        jPanel3.setBackground(new java.awt.Color(0, 0, 0));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton7.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton7.setText("DASHBOARD");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 170, 40));

        jButton10.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton10.setText("DOCTOR");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 170, 40));

        jButton11.setBackground(new java.awt.Color(0, 255, 255));
        jButton11.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton11.setForeground(new java.awt.Color(255, 0, 0));
        jButton11.setText("DIAGNOSIS");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 170, 40));

        jButton12.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton12.setText("PATIENT");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 170, 40));

        jButton13.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 17)); // NOI18N
        jButton13.setText("APPOINTMENT");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 170, 40));

        jButton14.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton14.setText("FACILITIES");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton14, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 170, 40));

        jButton15.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton15.setText("PAYMENT");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton15, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 320, 170, 40));

        jButton16.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton16.setText("ACCOUNT");
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton16, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 360, 170, 40));

        jButton6.setBackground(new java.awt.Color(255, 255, 0));
        jButton6.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton6.setText("BACK");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 400, 170, 40));

        jButton1.setBackground(new java.awt.Color(255, 0, 0));
        jButton1.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton1.setText("LOGOUT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 440, 170, 40));

        jButton2.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 25)); // NOI18N
        jButton2.setText("HOME");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 170, 40));

        jButton3.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 20)); // NOI18N
        jButton3.setText("PHARMACY");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 280, 170, 40));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 170, 480));

        jPanel4.setBackground(new java.awt.Color(51, 204, 255));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Berlin Sans FB", 1, 35)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("DIAGNOSIS INFORMATION");
        jPanel4.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 10, 460, -1));

        jLabel2.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel2.setText("PATIENT ID :");
        jPanel4.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 60, -1, -1));

        jLabel3.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel3.setText("NAME :");
        jPanel4.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, -1, -1));

        jLabel5.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel5.setText("DIAGNOSIS :");
        jPanel4.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(467, 65, -1, -1));

        jLabel6.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel6.setText("MEDICINE :");
        jPanel4.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 103, -1, -1));

        jLabel7.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel7.setText("DOCTOR :");
        jPanel4.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(73, 140, -1, -1));

        PatientBox2.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        PatientBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1234", "1345", "5356", "5156" }));
        PatientBox2.setSelectedIndex(-1);
        jPanel4.add(PatientBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 60, 250, -1));

        NameText2.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jPanel4.add(NameText2, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 100, 250, -1));

        DoctorBox.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        DoctorBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "DR. PETER  ROLLON", "DR. ALBERTO GUAVA", "DR. CHARLIZE CADEL", "DR. NEGATRON LISKA", " ", " " }));
        DoctorBox.setSelectedIndex(-1);
        jPanel4.add(DoctorBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 140, 250, -1));

        DiagnosisBox.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        DiagnosisBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "FLU", "HEADACHE", "SORE THROAT", "ACNE", "FOOD POISONING", "DIARRHEA", "MIGRAINE", "CHICKENPOX", " ", " " }));
        DiagnosisBox.setSelectedIndex(-1);
        jPanel4.add(DiagnosisBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 60, 295, -1));

        MedicineBox.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        MedicineBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "PARACETAMOL", "IBUPROFEN", "COUGH SYRUP", "PROBIOTICS", "STRESPSILS", "LOSARTAN", "ANTIFUNGAL CREAMS", "PAIN RELIEVERS" }));
        MedicineBox.setSelectedIndex(-1);
        jPanel4.add(MedicineBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 100, -1, -1));

        SaveDiagnosis.setBackground(new java.awt.Color(0, 153, 255));
        SaveDiagnosis.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 15)); // NOI18N
        SaveDiagnosis.setText("SAVE");
        SaveDiagnosis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveDiagnosisActionPerformed(evt);
            }
        });
        jPanel4.add(SaveDiagnosis, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 180, -1, -1));

        UpdateDiagnosis.setBackground(new java.awt.Color(0, 255, 255));
        UpdateDiagnosis.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 15)); // NOI18N
        UpdateDiagnosis.setText("UPDATE");
        UpdateDiagnosis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateDiagnosisActionPerformed(evt);
            }
        });
        jPanel4.add(UpdateDiagnosis, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 180, -1, -1));

        ClearDiagnosis.setBackground(new java.awt.Color(0, 204, 0));
        ClearDiagnosis.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 15)); // NOI18N
        ClearDiagnosis.setText("CLEAR");
        ClearDiagnosis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearDiagnosisActionPerformed(evt);
            }
        });
        jPanel4.add(ClearDiagnosis, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 180, -1, -1));

        DeleteDiagnosis.setBackground(new java.awt.Color(255, 0, 0));
        DeleteDiagnosis.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 15)); // NOI18N
        DeleteDiagnosis.setText("DELETE");
        DeleteDiagnosis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteDiagnosisActionPerformed(evt);
            }
        });
        jPanel4.add(DeleteDiagnosis, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 180, -1, -1));

        jButton4.setBackground(new java.awt.Color(255, 102, 255));
        jButton4.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 15)); // NOI18N
        jButton4.setText("PROCEED");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 180, 110, -1));

        jLabel10.setIcon(new javax.swing.ImageIcon("C:\\Users\\MK\\Downloads\\colorborder2.jpg")); // NOI18N
        jPanel4.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 220));

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 80, 940, 220));

        PatientTable2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        PatientTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "FirstName", "LastName", "Age", "Gender", "Disease", "DateBirth", "Status", "Number", "Address", "Blood"
            }
        ));
        PatientTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PatientTable2MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(PatientTable2);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 310, 940, 120));

        DiagnosisTable.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        DiagnosisTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "Patient ID", "Doctor", "Diagnosis", "Medicine"
            }
        ));
        DiagnosisTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DiagnosisTableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(DiagnosisTable);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 440, 940, 120));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1140, 570));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        DashBoardAdmin admin = new DashBoardAdmin();
        admin.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        DoctorFrame doctor = new DoctorFrame();
        doctor.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        String AdminPass = "shiro"; // Predefined password
        String inputPassword = JOptionPane.showInputDialog(null, "Enter Password:", "Password Required", JOptionPane.PLAIN_MESSAGE);

        if (inputPassword != null && inputPassword.equals(AdminPass)) {
            DiagnosisFrame diagnosis = new DiagnosisFrame();
            diagnosis.setVisible(true);
            this.setVisible(false);
        } else {
            JOptionPane.showMessageDialog(null, "Access Denied!");
        }
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        PatientFrame patient = new PatientFrame();
        patient.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        AppointmentFrame appointment = new AppointmentFrame();
        appointment.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        FacilitiesFrame facilities = new FacilitiesFrame();
        facilities.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        InventoryFrame pharmacy = new InventoryFrame();
        pharmacy.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton15ActionPerformed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
        String AdminPass = "shiro"; // Predefined password
        String inputPassword = JOptionPane.showInputDialog(null, "Enter Password:", "Password Required", JOptionPane.PLAIN_MESSAGE);

        if (inputPassword != null && inputPassword.equals(AdminPass)) {
             AccountFrame account = new AccountFrame();
            account.setVisible(true);
            this.setVisible(false);
        } else {
            JOptionPane.showMessageDialog(null, "Access Denied!");
        }
    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        DashBoardAdmin back = new DashBoardAdmin();
        back.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        int exit = JOptionPane.showConfirmDialog(null,"Are you sure you want to Log out?","Confirmation",JOptionPane.YES_NO_OPTION,
                JOptionPane.INFORMATION_MESSAGE);
        if (exit == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
        else {
            JOptionPane.showMessageDialog(null, "Cancellation Confirm.");
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void DeleteDiagnosisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteDiagnosisActionPerformed
        DefaultTableModel model = (DefaultTableModel)DiagnosisTable.getModel();
        
        if(DiagnosisTable.getSelectedRowCount()==1){
            model.removeRow(DiagnosisTable.getSelectedRow());
        
        }else {
            if(DiagnosisTable.getSelectedRowCount()==0){
                JOptionPane.showMessageDialog(this, "Please Select a single row to Delete", "Input Error!", JOptionPane.ERROR_MESSAGE);          
            }           
        }
    }//GEN-LAST:event_DeleteDiagnosisActionPerformed

    private void ClearDiagnosisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearDiagnosisActionPerformed
            if (NameText2.getText().isEmpty() &&
                PatientBox2.getSelectedIndex() == -1 &&
                DoctorBox.getSelectedIndex() == -1 &&               
                DiagnosisBox.getSelectedIndex() == -1 &&
                MedicineBox.getSelectedIndex() == -1 ) {
                
                JOptionPane.showMessageDialog(null, "There are no text to clear",
                "Input Error", JOptionPane.ERROR_MESSAGE);
            }
            else{
                NameText2.setText("");
                PatientBox2.setSelectedIndex(-1);
                DoctorBox.setSelectedIndex(-1);                
                DiagnosisBox.setSelectedIndex(-1);
                MedicineBox.setSelectedIndex(-1);
            }
    }//GEN-LAST:event_ClearDiagnosisActionPerformed

    private void SaveDiagnosisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveDiagnosisActionPerformed
         DefaultTableModel model = (DefaultTableModel) DiagnosisTable.getModel();
         
         String Name = NameText2.getText().trim();
         String patient2 = (PatientBox2.getSelectedItem() != null) ? PatientBox2.getSelectedItem().toString().trim() : "";
         String doctor = (DoctorBox.getSelectedItem() != null) ? DoctorBox.getSelectedItem().toString().trim() : "";
         String diagnosis2 = (DiagnosisBox.getSelectedItem() != null) ? DiagnosisBox.getSelectedItem().toString().trim() : "";
         String medicine = (MedicineBox.getSelectedItem() != null) ? MedicineBox.getSelectedItem().toString().trim() : "";
         
         if(Name.isEmpty() || patient2.isEmpty() || doctor.isEmpty() || diagnosis2.isEmpty() || medicine.isEmpty()) {
            JOptionPane.showMessageDialog(this,
            "There are empty spots, please fill up again.",
            "Input Error",
            JOptionPane.ERROR_MESSAGE);
            return;
        } 
            model.addRow(new Object[] {
                Name, patient2, doctor, diagnosis2, medicine         
            });
            // Add to static ArrayList
            Hospital_Management.Diagnosis newDiagnosis = new Hospital_Management.Diagnosis(
            Name, patient2, doctor, diagnosis2, medicine);
            
            Hospital_Management.diagnosis.add(newDiagnosis);
        JOptionPane.showMessageDialog(this, "Diagnos saved successfully.");
         
    }//GEN-LAST:event_SaveDiagnosisActionPerformed

    private void UpdateDiagnosisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateDiagnosisActionPerformed
        int selectedRow = DiagnosisTable.getSelectedRow();
        if (selectedRow != -1) {   
        String Name = NameText2.getText();
        String patient2 = (String) PatientBox2.getSelectedItem();
        String doctor = (String) DoctorBox.getSelectedItem();
        String diagnosis = (String) DiagnosisBox.getSelectedItem();
        String medicine = (String) MedicineBox.getSelectedItem();
        
        DefaultTableModel model = (DefaultTableModel)DiagnosisTable.getModel();
            
            model.setValueAt(patient2, selectedRow, 1);
            model.setValueAt(Name, selectedRow,0);
            model.setValueAt(doctor, selectedRow, 2);
            model.setValueAt(diagnosis, selectedRow, 3);
            model.setValueAt(medicine, selectedRow, 4);
            
            Hospital_Management.diagnosis.set(selectedRow, new Hospital_Management.Diagnosis(Name, patient2, doctor, diagnosis, medicine));
            
            JOptionPane.showMessageDialog(this, "Update Successfully...");
        }else {
            JOptionPane.showMessageDialog(this, "Please Select a single row to Update!", "Input Error", JOptionPane.ERROR_MESSAGE);
        }         
    }//GEN-LAST:event_UpdateDiagnosisActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        HomeFrame home = new HomeFrame();
        home.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void PatientTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PatientTable2MouseClicked
        DefaultTableModel model = (DefaultTableModel)PatientTable2.getModel();    
    }//GEN-LAST:event_PatientTable2MouseClicked

    private void DiagnosisTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DiagnosisTableMouseClicked
        DefaultTableModel model = (DefaultTableModel)DiagnosisTable.getModel();
        
    }//GEN-LAST:event_DiagnosisTableMouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        InventoryFrame pharmacy = new InventoryFrame();
        pharmacy.setVisible(true);
        this.setVisible(false);        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        FacilitiesFrame facilities = new FacilitiesFrame();
        facilities.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DiagnosisFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DiagnosisFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DiagnosisFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DiagnosisFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DiagnosisFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ClearDiagnosis;
    private javax.swing.JButton DeleteDiagnosis;
    private javax.swing.JComboBox<String> DiagnosisBox;
    private javax.swing.JTable DiagnosisTable;
    private javax.swing.JComboBox<String> DoctorBox;
    private javax.swing.JComboBox<String> MedicineBox;
    private javax.swing.JTextField NameText2;
    private javax.swing.JComboBox<String> PatientBox2;
    private javax.swing.JTable PatientTable2;
    private javax.swing.JButton SaveDiagnosis;
    private javax.swing.JButton UpdateDiagnosis;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
