/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.hospital_management;


import javax.swing.JOptionPane;


public class LoginFrame extends javax.swing.JFrame {

    public LoginFrame() {
        initComponents();
        setLocationRelativeTo(null);
        
    }
      
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        UsernameLogin = new javax.swing.JTextField();
        eyeshow = new javax.swing.JLabel();
        eyehide = new javax.swing.JLabel();
        PasswordLogin = new javax.swing.JPasswordField();
        EnterLogin = new javax.swing.JButton();
        ClearLogin = new javax.swing.JButton();
        RegisterLogin = new javax.swing.JButton();
        ExitLogin = new javax.swing.JButton();
        BackLogin = new javax.swing.JButton();
        AdminButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 0, 0,80));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Berlin Sans FB", 1, 35)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("LOGIN");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 40, -1, 29));

        jLabel3.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("USERNAME :");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 120, -1, 30));

        jLabel4.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("PASSWORD :");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 170, -1, 30));

        UsernameLogin.setFont(new java.awt.Font("Century Gothic", 1, 15)); // NOI18N
        UsernameLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UsernameLoginActionPerformed(evt);
            }
        });
        jPanel1.add(UsernameLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 120, 200, 30));

        eyeshow.setIcon(new javax.swing.ImageIcon("C:\\Users\\MK\\Downloads\\view (1).png")); // NOI18N
        jPanel1.add(eyeshow, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 175, 20, 20));

        eyehide.setIcon(new javax.swing.ImageIcon("C:\\Users\\MK\\Downloads\\hide (1).png")); // NOI18N
        eyehide.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                eyehideMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                eyehideMouseReleased(evt);
            }
        });
        jPanel1.add(eyehide, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 175, -1, -1));

        PasswordLogin.setFont(new java.awt.Font("Century Gothic", 1, 15)); // NOI18N
        jPanel1.add(PasswordLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 170, 200, 30));

        EnterLogin.setBackground(new java.awt.Color(255, 255, 0));
        EnterLogin.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        EnterLogin.setText("ENTER");
        EnterLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EnterLoginActionPerformed(evt);
            }
        });
        jPanel1.add(EnterLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 260, 110, 55));

        ClearLogin.setBackground(new java.awt.Color(0, 204, 0));
        ClearLogin.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        ClearLogin.setText("CLEAR");
        ClearLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearLoginActionPerformed(evt);
            }
        });
        jPanel1.add(ClearLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 260, 110, 55));

        RegisterLogin.setBackground(new java.awt.Color(0, 153, 255));
        RegisterLogin.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        RegisterLogin.setText("REGISTER");
        RegisterLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegisterLoginActionPerformed(evt);
            }
        });
        jPanel1.add(RegisterLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 260, 110, 55));

        ExitLogin.setBackground(new java.awt.Color(255, 0, 0));
        ExitLogin.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        ExitLogin.setText("LOGOUT");
        ExitLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitLoginActionPerformed(evt);
            }
        });
        jPanel1.add(ExitLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 360, -1, 35));

        BackLogin.setBackground(new java.awt.Color(255, 255, 0));
        BackLogin.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        BackLogin.setText("BACK");
        BackLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackLoginActionPerformed(evt);
            }
        });
        jPanel1.add(BackLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, -1, 35));

        AdminButton.setBackground(new java.awt.Color(51, 255, 204));
        AdminButton.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        AdminButton.setText("ADMIN ACCOUNT");
        AdminButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AdminButtonActionPerformed(evt);
            }
        });
        jPanel1.add(AdminButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 230, 250, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(255, 100, 610, 410));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\MK\\OneDrive - National University\\Documents\\NetBeansProjects\\Hospital_Management\\src\\main\\java\\com\\mycompany\\hospital_management\\Hospital Management FINALS (4).jpg")); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1140, 570));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AdminButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AdminButtonActionPerformed
        AdminPassFrame admin = new AdminPassFrame();
        admin.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_AdminButtonActionPerformed

    private void BackLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackLoginActionPerformed
        HomeFrame home = new HomeFrame();
        home.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_BackLoginActionPerformed

    private void ExitLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitLoginActionPerformed
        int exit = JOptionPane.showConfirmDialog(null,"Are you sure you want to Log out?","Confirmation",JOptionPane.YES_NO_OPTION,
                JOptionPane.INFORMATION_MESSAGE);
        if (exit == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
        else {
            JOptionPane.showMessageDialog(null, "Cancellation Confirm.");
        }
    }//GEN-LAST:event_ExitLoginActionPerformed

    private void RegisterLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegisterLoginActionPerformed
        String AdminPass = "shiro";
        int option = JOptionPane.showConfirmDialog(null, PasswordLogin, "Enter Password", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (option == JOptionPane.OK_OPTION) {
            char[] password = PasswordLogin.getPassword();
            String passwordStr = new String(password);

            if (passwordStr.equals(AdminPass)) {
                JOptionPane.showMessageDialog(null, "Access Granted!");
                RegisterFrame register = new RegisterFrame();
                register.setVisible(true);
                this.setVisible(false);
            } else {
                JOptionPane.showMessageDialog(null, "Access Denied!");
            }
        }

    }//GEN-LAST:event_RegisterLoginActionPerformed

    private void ClearLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearLoginActionPerformed
        UsernameLogin.setText("");
        PasswordLogin.setText("");
    }//GEN-LAST:event_ClearLoginActionPerformed

    private void EnterLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EnterLoginActionPerformed
        String username1 = UsernameLogin.getText();
        String password1 = PasswordLogin.getText();
                                                
        int a = Hospital_Management.Username.size();
        int i;
        String AdminPass = "shiro";

        if(Hospital_Management.Username.indexOf(username1)>=0) {
            for (i = 0; i < a;)
            {
                if (!username1.equals(Hospital_Management.Username.get(i)))
                {
                    i++;
                }
                else
                {
                    if (!password1.equals(Hospital_Management.Password.get(i))) {
                        JOptionPane.showMessageDialog(null, "Incorrect Password for " + username1 + " account.");
                        UsernameLogin.setText("");
                        PasswordLogin.setText("");
                        break;
                    }                                        
                    else
                    {
                        JOptionPane.showMessageDialog(null, "LOGIN SUCCESSFUL!");
                        MenuFrame menu = new MenuFrame();
                        menu.setVisible(true);
                        this.setVisible(false);
                        break;
                    }
                }
            }
        }           
        else if (username1.equals("admin")) {
            if(password1.equals(AdminPass)) {
                JOptionPane.showMessageDialog(null, "ADMIN LOGIN SUCCESSFUL!");
                DashBoardAdmin adminDashboard = new DashBoardAdmin();
                adminDashboard.setVisible(true);
                this.setVisible(false);
            }
            else {
                JOptionPane.showMessageDialog(null, "Incorrect Admin Password!");
                UsernameLogin.setText("");
                PasswordLogin.setText("");
            }
        } 
        else
        {
            JOptionPane.showMessageDialog(null, "Username doesn't exit!");
            UsernameLogin.setText("");
            PasswordLogin.setText("");
        }
    }//GEN-LAST:event_EnterLoginActionPerformed

    private void eyehideMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_eyehideMouseReleased
        eyeshow.setVisible(false);
        eyehide.setVisible(true);
        PasswordLogin.setEchoChar('*');
    }//GEN-LAST:event_eyehideMouseReleased

    private void eyehideMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_eyehideMousePressed
        eyeshow.setVisible(true);
        eyehide.setVisible(false);
        PasswordLogin.setEchoChar((char)0);
    }//GEN-LAST:event_eyehideMousePressed

    private void UsernameLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UsernameLoginActionPerformed
        
    }//GEN-LAST:event_UsernameLoginActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LoginFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LoginFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LoginFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LoginFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LoginFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AdminButton;
    private javax.swing.JButton BackLogin;
    private javax.swing.JButton ClearLogin;
    private javax.swing.JButton EnterLogin;
    private javax.swing.JButton ExitLogin;
    private javax.swing.JPasswordField PasswordLogin;
    private javax.swing.JButton RegisterLogin;
    private javax.swing.JTextField UsernameLogin;
    private javax.swing.JLabel eyehide;
    private javax.swing.JLabel eyeshow;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
