/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.hospital_management;

import javax.swing.JOptionPane;


public class RegisterFrame extends javax.swing.JFrame {

    
    public RegisterFrame() {
        initComponents();
        setLocationRelativeTo(null);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        NameRegister = new javax.swing.JTextField();
        UsernameRegister = new javax.swing.JTextField();
        eyeshow2 = new javax.swing.JLabel();
        eyehide2 = new javax.swing.JLabel();
        PasswordRegister = new javax.swing.JPasswordField();
        eyeshow3 = new javax.swing.JLabel();
        eyehide3 = new javax.swing.JLabel();
        ReEnterRegister = new javax.swing.JPasswordField();
        SaveRegister = new javax.swing.JButton();
        ClearRegister = new javax.swing.JButton();
        LoginRegister = new javax.swing.JButton();
        ExitRegister = new javax.swing.JButton();
        BackRegister = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        Disclaimercheckbox = new javax.swing.JCheckBox();
        jLabel1 = new javax.swing.JLabel();
        DataPrivacy = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 0, 0,80));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Berlin Sans FB", 1, 35)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("REGISTER ACCOUNT");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 20, 350, 36));

        jLabel3.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("NAME :");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(194, 90, 70, 30));

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("USERNAME :");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 140, 123, 30));

        jLabel5.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("PASSWORD :");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(137, 190, -1, 30));

        jLabel6.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("RE-ENTER :");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(151, 240, -1, 30));

        NameRegister.setFont(new java.awt.Font("Century Gothic", 1, 15)); // NOI18N
        NameRegister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NameRegisterActionPerformed(evt);
            }
        });
        jPanel1.add(NameRegister, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 90, 200, 30));

        UsernameRegister.setFont(new java.awt.Font("Century Gothic", 1, 15)); // NOI18N
        UsernameRegister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UsernameRegisterActionPerformed(evt);
            }
        });
        jPanel1.add(UsernameRegister, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 140, 200, 30));

        eyeshow2.setIcon(new javax.swing.ImageIcon("C:\\Users\\MK\\Downloads\\view (1).png")); // NOI18N
        jPanel1.add(eyeshow2, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 195, -1, -1));

        eyehide2.setIcon(new javax.swing.ImageIcon("C:\\Users\\MK\\Downloads\\hide (1).png")); // NOI18N
        eyehide2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                eyehide2MousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                eyehide2MouseReleased(evt);
            }
        });
        jPanel1.add(eyehide2, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 195, -1, -1));

        PasswordRegister.setFont(new java.awt.Font("Century Gothic", 1, 15)); // NOI18N
        jPanel1.add(PasswordRegister, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 190, 200, 30));

        eyeshow3.setIcon(new javax.swing.ImageIcon("C:\\Users\\MK\\Downloads\\view (1).png")); // NOI18N
        jPanel1.add(eyeshow3, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 245, -1, -1));

        eyehide3.setIcon(new javax.swing.ImageIcon("C:\\Users\\MK\\Downloads\\hide (1).png")); // NOI18N
        eyehide3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                eyehide3MousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                eyehide3MouseReleased(evt);
            }
        });
        jPanel1.add(eyehide3, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 245, -1, -1));

        ReEnterRegister.setFont(new java.awt.Font("Century Gothic", 1, 15)); // NOI18N
        ReEnterRegister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReEnterRegisterActionPerformed(evt);
            }
        });
        jPanel1.add(ReEnterRegister, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 240, 200, 30));

        SaveRegister.setBackground(new java.awt.Color(51, 102, 255));
        SaveRegister.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        SaveRegister.setText("SAVE");
        SaveRegister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveRegisterActionPerformed(evt);
            }
        });
        jPanel1.add(SaveRegister, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 330, 110, 50));

        ClearRegister.setBackground(new java.awt.Color(0, 204, 0));
        ClearRegister.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        ClearRegister.setText("CLEAR");
        ClearRegister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearRegisterActionPerformed(evt);
            }
        });
        jPanel1.add(ClearRegister, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 330, 110, 50));

        LoginRegister.setBackground(new java.awt.Color(0, 255, 255));
        LoginRegister.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        LoginRegister.setText("LOGIN");
        LoginRegister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoginRegisterActionPerformed(evt);
            }
        });
        jPanel1.add(LoginRegister, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 330, 110, 50));

        ExitRegister.setBackground(new java.awt.Color(255, 0, 0));
        ExitRegister.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        ExitRegister.setText("LOGOUT");
        ExitRegister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitRegisterActionPerformed(evt);
            }
        });
        jPanel1.add(ExitRegister, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 400, -1, 35));

        BackRegister.setBackground(new java.awt.Color(255, 255, 204));
        BackRegister.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        BackRegister.setText("BACK");
        BackRegister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackRegisterActionPerformed(evt);
            }
        });
        jPanel1.add(BackRegister, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, -1, 35));

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Disclaimercheckbox.setText("DISCLAIMER FOR DATA PRIVACY");
        Disclaimercheckbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DisclaimercheckboxActionPerformed(evt);
            }
        });
        jPanel2.add(Disclaimercheckbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 270, 205, 30));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 60, 700, 450));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\MK\\Downloads\\Hospital Management FINALS (4).jpg")); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1140, 570));

        DataPrivacy.setForeground(new java.awt.Color(255, 0, 0));
        DataPrivacy.setText("*DISCLAIMER FOR DATA PRIVACY*");
        DataPrivacy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DataPrivacyActionPerformed(evt);
            }
        });
        getContentPane().add(DataPrivacy, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 530, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void NameRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NameRegisterActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NameRegisterActionPerformed

    private void UsernameRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UsernameRegisterActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UsernameRegisterActionPerformed

    private void ClearRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearRegisterActionPerformed
        NameRegister.setText("");
        UsernameRegister.setText("");
        PasswordRegister.setText("");
        ReEnterRegister.setText("");
    }//GEN-LAST:event_ClearRegisterActionPerformed

    private void ExitRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitRegisterActionPerformed
        int exit = JOptionPane.showConfirmDialog(null,"Are you sure you want to Log out?","Confirmation",JOptionPane.YES_NO_OPTION,
                JOptionPane.INFORMATION_MESSAGE);
        if (exit == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
        else {
            JOptionPane.showMessageDialog(null, "Cancellation Confirm.");
        }
    }//GEN-LAST:event_ExitRegisterActionPerformed

    private void LoginRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoginRegisterActionPerformed
        LoginFrame login = new LoginFrame();
        login.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_LoginRegisterActionPerformed

    private void SaveRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveRegisterActionPerformed
        if (!Disclaimercheckbox.isSelected()) {
        JOptionPane.showMessageDialog(this, "You must agree to the Data Privacy Policy to proceed.", "Agreement Required", JOptionPane.WARNING_MESSAGE);
        return; // Exit the method if the checkbox is not selected
        }
        
        String username = UsernameRegister.getText();
        String password = PasswordRegister.getText();
        String uname = NameRegister.getText();
        String reenter2 = ReEnterRegister.getText();
        
        if (username.length()<2){
            JOptionPane.showMessageDialog(this, "Username is to short! Must be at least 2 characters.", "Minimum of 2 character required", JOptionPane.WARNING_MESSAGE);
            UsernameRegister.getText();
            return;
        }else if (username.length()>20) {
            JOptionPane.showMessageDialog(this, "Username is to long! Mus be at least 20 characters.", "Minimum Character are met", JOptionPane.WARNING_MESSAGE);
            UsernameRegister.getText();
            return;
        }
        
        if(username.length()==0 || password.length()==0 || uname.length()==0 || reenter2.length()==0) {
           JOptionPane.showMessageDialog(this, "Please Fill all fiels", "Incomplete", JOptionPane.WARNING_MESSAGE);
           return;
        }
//        for () {
//        } ahh para sa accountframe to yung lahat pede e save 
               
        if (!password.equals(reenter2)) {
            JOptionPane.showMessageDialog(this, "Password do not Match!", "PASSWORD INCCORECT!", JOptionPane.WARNING_MESSAGE);
            PasswordRegister.getText();
            ReEnterRegister.getText();
            return;
        }
        if (password.length() < 10) {
            JOptionPane.showMessageDialog(this, "Password must contain 10 or more characters", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
                
        Hospital_Management.Username.add(username);
        Hospital_Management.Password.add(password);
        Hospital_Management.Uname.add(uname);
        Hospital_Management.ReEnter2.add(reenter2);
        JOptionPane.showMessageDialog(null, "New Account Registered!");

    }//GEN-LAST:event_SaveRegisterActionPerformed

    private void ReEnterRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReEnterRegisterActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ReEnterRegisterActionPerformed

    private void DataPrivacyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DataPrivacyActionPerformed
        int response1 = JOptionPane.showConfirmDialog(null, "Do you agree to our Data Privacy Policy?", "Disclaimer", JOptionPane.WARNING_MESSAGE,JOptionPane.YES_NO_OPTION);
        if (response1 == JOptionPane.NO_OPTION) {
            JOptionPane.showMessageDialog(null, " You did not agree. Exiting...");
            System.exit(0);
        }
        else {
            JOptionPane.showMessageDialog(null, "You agree! Proceeding!...");
        }
    }//GEN-LAST:event_DataPrivacyActionPerformed

    private void BackRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackRegisterActionPerformed
        LoginFrame login = new LoginFrame();
        login.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_BackRegisterActionPerformed

    private void eyehide2MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_eyehide2MouseReleased
        eyeshow2.setVisible(false);
        eyehide2.setVisible(true);
        eyeshow3.setVisible(false);
        eyehide3.setVisible(true);
        PasswordRegister.setEchoChar('*');
        ReEnterRegister.setEchoChar('*');
    }//GEN-LAST:event_eyehide2MouseReleased

    private void eyehide2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_eyehide2MousePressed
        eyeshow2.setVisible(true);
        eyehide2.setVisible(false);
        eyeshow3.setVisible(true);
        eyehide3.setVisible(false);
        PasswordRegister.setEchoChar((char)0);
        ReEnterRegister.setEchoChar((char)0);
    }//GEN-LAST:event_eyehide2MousePressed

    private void eyehide3MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_eyehide3MouseReleased
        eyeshow3.setVisible(false);
        eyehide3.setVisible(true);
        eyeshow2.setVisible(false);
        eyehide2.setVisible(true);
        PasswordRegister.setEchoChar('*');
        ReEnterRegister.setEchoChar('*');
    }//GEN-LAST:event_eyehide3MouseReleased

    private void eyehide3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_eyehide3MousePressed
        eyeshow3.setVisible(true);
        eyehide3.setVisible(false);
        eyeshow2.setVisible(true);
        eyehide2.setVisible(false);
        PasswordRegister.setEchoChar((char)0);
        ReEnterRegister.setEchoChar((char)0);
    }//GEN-LAST:event_eyehide3MousePressed

    private void DisclaimercheckboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DisclaimercheckboxActionPerformed
        int response1 = JOptionPane.showConfirmDialog(null, "Do you agree to our Data Privacy Policy?", "Disclaimer", JOptionPane.YES_NO_OPTION);
        if (response1 == JOptionPane.NO_OPTION) {
            JOptionPane.showMessageDialog(null, " You did not agree. Exiting...");
            System.exit(0);
        }
        else {
            JOptionPane.showMessageDialog(null, "You agree! Proceeding!...");
        }
    }//GEN-LAST:event_DisclaimercheckboxActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegisterFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegisterFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegisterFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegisterFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegisterFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BackRegister;
    private javax.swing.JButton ClearRegister;
    private javax.swing.JButton DataPrivacy;
    private javax.swing.JCheckBox Disclaimercheckbox;
    private javax.swing.JButton ExitRegister;
    private javax.swing.JButton LoginRegister;
    private javax.swing.JTextField NameRegister;
    private javax.swing.JPasswordField PasswordRegister;
    private javax.swing.JPasswordField ReEnterRegister;
    private javax.swing.JButton SaveRegister;
    private javax.swing.JTextField UsernameRegister;
    private javax.swing.JLabel eyehide2;
    private javax.swing.JLabel eyehide3;
    private javax.swing.JLabel eyeshow2;
    private javax.swing.JLabel eyeshow3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
